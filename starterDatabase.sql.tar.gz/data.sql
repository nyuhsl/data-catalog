-- MySQL dump 10.13  Distrib 5.6.38, for Linux (x86_64)
--
-- Host: localhost    Database: nyu
-- ------------------------------------------------------
-- Server version	5.6.38

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `access_restrictions`
--

DROP TABLE IF EXISTS `access_restrictions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `access_restrictions` (
  `restriction_id` int(11) NOT NULL AUTO_INCREMENT,
  `restriction` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`restriction_id`),
  UNIQUE KEY `UNIQ_BBE421657A999BCE` (`restriction`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_restrictions`
--

LOCK TABLES `access_restrictions` WRITE;
/*!40000 ALTER TABLE `access_restrictions` DISABLE KEYS */;
INSERT INTO `access_restrictions` VALUES (1,'Application Required','application-required'),(2,'Free to All','free-to-all'),(3,'Free to all with registration','free-to-all-with-registration');
/*!40000 ALTER TABLE `access_restrictions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `awards`
--

DROP TABLE IF EXISTS `awards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `awards` (
  `award_id` int(11) NOT NULL AUTO_INCREMENT,
  `award` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `award_funder` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `award_url` varchar(1028) COLLATE utf8_unicode_ci DEFAULT NULL,
  `funder_type` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`award_id`),
  UNIQUE KEY `UNIQ_25EAE3FE8A5B2EE7` (`award`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `awards`
--

LOCK TABLES `awards` WRITE;
/*!40000 ALTER TABLE `awards` DISABLE KEYS */;
/*!40000 ALTER TABLE `awards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_form_emails`
--

DROP TABLE IF EXISTS `contact_form_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_form_emails` (
  `email_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` varchar(18) COLLATE utf8_unicode_ci NOT NULL,
  `full_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `email_address` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `affiliation` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reason` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `checker` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `message_body` varchar(1028) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`email_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_form_emails`
--

LOCK TABLES `contact_form_emails` WRITE;
/*!40000 ALTER TABLE `contact_form_emails` DISABLE KEYS */;
INSERT INTO `contact_form_emails` VALUES (1,'adp6j','anson parker','adp6j@virginia.edu','Generic School of Medicine','General inquiry',NULL,'test'),(2,'adp6j','anson parker','ansondparker@gmail.com','School of Medicine','General inquiry',NULL,'test'),(3,'adp6j','anson parker','ansondparker@gmail.com','School of Medicine','General inquiry',NULL,'test');
/*!40000 ALTER TABLE `contact_form_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_location_urls`
--

DROP TABLE IF EXISTS `data_location_urls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_location_urls` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `datasets_dataset_uid` int(11) DEFAULT NULL,
  `data_access_url` varchar(1028) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `IDX_5BD296CBAD3AFC` (`datasets_dataset_uid`),
  CONSTRAINT `FK_5BD296CBAD3AFC` FOREIGN KEY (`datasets_dataset_uid`) REFERENCES `datasets` (`dataset_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_location_urls`
--

LOCK TABLES `data_location_urls` WRITE;
/*!40000 ALTER TABLE `data_location_urls` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_location_urls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_locations`
--

DROP TABLE IF EXISTS `data_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_locations` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `datasets_dataset_uid` int(11) DEFAULT NULL,
  `data_location` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `location_content` varchar(1028) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data_access_url` varchar(1028) COLLATE utf8_unicode_ci NOT NULL,
  `accession_number` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`location_id`),
  KEY `IDX_98490A8CAD3AFC` (`datasets_dataset_uid`),
  CONSTRAINT `FK_98490A8CAD3AFC` FOREIGN KEY (`datasets_dataset_uid`) REFERENCES `datasets` (`dataset_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_locations`
--

LOCK TABLES `data_locations` WRITE;
/*!40000 ALTER TABLE `data_locations` DISABLE KEYS */;
INSERT INTO `data_locations` VALUES (1,2,'WHI','Datasets offered through the WHI website','https://www.whi.org/researchers/data/Pages/Home.aspx',NULL),(2,2,'BioLINCC','WHI clinical trial and epidemiology study data','https://biolincc.nhlbi.nih.gov/studies/whi-other',NULL),(3,2,'BioLINCC','WHI observational study data','WHI observational study data',NULL),(4,2,'dbGaP','Clinical trial, observational study, exome sequencing, genotype and phenotype data','http://www.ncbi.nlm.nih.gov/projects/gap/cgi-bin/dataset.cgi?study_id=phs000200.v9.p3&phv=161362&phd=2022&pha=&pht=1515&phvf=&phdf=&phaf=&phtf=&phs_code=&dssp=1&consent=&temp=1',NULL),(5,3,'University of Texas Health Science Center','Clinical trial, lab analysis, outcome, and ECG data','https://ccct.sph.uth.tmc.edu/allhatoutreach/Datasets/ToObtainALLHATData.aspx',NULL),(6,3,'BioLINCC','Limited access clinical trial data','https://biolincc.nhlbi.nih.gov/studies/allhat/',NULL),(7,4,'USRDS',NULL,'http://www.usrds.org/adr.aspx',NULL);
/*!40000 ALTER TABLE `data_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_types`
--

DROP TABLE IF EXISTS `data_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_types` (
  `data_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `data_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`data_type_id`),
  UNIQUE KEY `UNIQ_178F45AF37919CCB` (`data_type`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_types`
--

LOCK TABLES `data_types` WRITE;
/*!40000 ALTER TABLE `data_types` DISABLE KEYS */;
INSERT INTO `data_types` VALUES (1,'Administrative','administrative'),(2,'Surveys','surveys'),(3,'Biospecimens','biospecimens'),(4,'Clinical Measures','clinical-measures'),(5,'Behavioral','behavioral'),(6,'Genomic','genomic'),(7,'Electrophysiological','electrophysiological');
/*!40000 ALTER TABLE `data_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datacatalog_user_roles`
--

DROP TABLE IF EXISTS `datacatalog_user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datacatalog_user_roles` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `role` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `UNIQ_F1263A5F57698A6A` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datacatalog_user_roles`
--

LOCK TABLES `datacatalog_user_roles` WRITE;
/*!40000 ALTER TABLE `datacatalog_user_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `datacatalog_user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datacatalog_users`
--

DROP TABLE IF EXISTS `datacatalog_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datacatalog_users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `lastName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `UNIQ_613DCE28F85E0677` (`username`),
  UNIQUE KEY `UNIQ_613DCE28989D9B62` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datacatalog_users`
--

LOCK TABLES `datacatalog_users` WRITE;
/*!40000 ALTER TABLE `datacatalog_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `datacatalog_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataset_alternate_titles`
--

DROP TABLE IF EXISTS `dataset_alternate_titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataset_alternate_titles` (
  `alternate_title_id` int(11) NOT NULL AUTO_INCREMENT,
  `datasets_dataset_uid` int(11) DEFAULT NULL,
  `alt_title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`alternate_title_id`),
  KEY `IDX_AA888C19AD3AFC` (`datasets_dataset_uid`),
  CONSTRAINT `FK_AA888C19AD3AFC` FOREIGN KEY (`datasets_dataset_uid`) REFERENCES `datasets` (`dataset_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataset_alternate_titles`
--

LOCK TABLES `dataset_alternate_titles` WRITE;
/*!40000 ALTER TABLE `dataset_alternate_titles` DISABLE KEYS */;
INSERT INTO `dataset_alternate_titles` VALUES (1,1,'AHRF'),(2,2,'WHI'),(3,3,'ALLHAT'),(4,4,'US Renal Data System'),(5,4,'USRDS');
/*!40000 ALTER TABLE `dataset_alternate_titles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataset_edits`
--

DROP TABLE IF EXISTS `dataset_edits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataset_edits` (
  `edit_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_dataset_uid` int(11) DEFAULT NULL,
  `user` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` datetime NOT NULL,
  `edit_type` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `edit_notes` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`edit_id`),
  KEY `IDX_96027375D9D2C924` (`parent_dataset_uid`),
  CONSTRAINT `FK_96027375D9D2C924` FOREIGN KEY (`parent_dataset_uid`) REFERENCES `datasets` (`dataset_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataset_edits`
--

LOCK TABLES `dataset_edits` WRITE;
/*!40000 ALTER TABLE `dataset_edits` DISABLE KEYS */;
INSERT INTO `dataset_edits` VALUES (1,1,'admin','2018-01-26 08:12:26','created',NULL),(2,1,'admin','2018-01-29 09:15:34','updated',NULL),(3,1,'admin','2018-01-29 09:19:30','updated',NULL),(4,1,'admin','2018-01-29 09:22:18','updated',NULL),(5,1,'admin','2018-01-29 09:23:09','updated',NULL),(6,1,'admin','2018-01-29 09:24:58','updated',NULL),(7,1,'admin','2018-01-29 09:26:19','updated',NULL),(8,1,'admin','2018-01-29 11:54:55','updated',NULL),(9,2,'admin','2018-01-29 12:37:49','created',NULL),(10,2,'admin','2018-01-29 12:39:17','updated',NULL),(11,2,'admin','2018-01-29 12:40:28','updated',NULL),(12,2,'admin','2018-01-29 12:47:27','updated',NULL),(13,2,'admin','2018-01-29 12:52:13','updated',NULL),(14,2,'admin','2018-01-29 12:55:01','updated',NULL),(15,2,'admin','2018-01-29 13:09:32','updated',NULL),(16,2,'admin','2018-01-29 13:10:32','updated',NULL),(17,2,'admin','2018-01-29 13:11:06','updated',NULL),(18,3,'admin','2018-01-29 14:10:06','created',NULL),(19,3,'admin','2018-01-29 14:10:21','updated',NULL),(20,4,'admin','2018-01-29 14:14:11','created',NULL),(21,4,'admin','2018-01-29 14:14:20','updated',NULL),(22,4,'admin','2018-01-29 14:16:09','updated',NULL),(23,4,'admin','2018-01-29 14:16:47','updated',NULL),(24,2,'admin','2018-01-31 15:00:15','updated',NULL);
/*!40000 ALTER TABLE `dataset_edits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataset_formats`
--

DROP TABLE IF EXISTS `dataset_formats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataset_formats` (
  `data_format_id` int(11) NOT NULL AUTO_INCREMENT,
  `format` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`data_format_id`),
  UNIQUE KEY `UNIQ_266E967ADEBA72DF` (`format`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataset_formats`
--

LOCK TABLES `dataset_formats` WRITE;
/*!40000 ALTER TABLE `dataset_formats` DISABLE KEYS */;
INSERT INTO `dataset_formats` VALUES (1,'ASCII','ascii'),(2,'Microsoft Access','microsoft-access'),(3,'SAS','sas'),(4,'PDF','pdf');
/*!40000 ALTER TABLE `dataset_formats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataset_relationships`
--

DROP TABLE IF EXISTS `dataset_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataset_relationships` (
  `relationship_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_dataset_uid` int(11) DEFAULT NULL,
  `relationship_attributes` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `relationship_notes` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `related_dataset_uid` int(11) NOT NULL,
  PRIMARY KEY (`relationship_id`),
  KEY `IDX_A88D9BC0D9D2C924` (`parent_dataset_uid`),
  CONSTRAINT `FK_A88D9BC0D9D2C924` FOREIGN KEY (`parent_dataset_uid`) REFERENCES `datasets` (`dataset_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataset_relationships`
--

LOCK TABLES `dataset_relationships` WRITE;
/*!40000 ALTER TABLE `dataset_relationships` DISABLE KEYS */;
INSERT INTO `dataset_relationships` VALUES (1,3,NULL,'Follow-up research drew on data from the USRDS, as well as the National Death Index, the Social Security Administration, the Department of Veterans Affairs and the Centers for Medicare and Medicaid Services',4);
/*!40000 ALTER TABLE `dataset_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasets`
--

DROP TABLE IF EXISTS `datasets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasets` (
  `dataset_uid` int(11) NOT NULL,
  `origin` varchar(16) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Internal',
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `slug` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(3000) COLLATE utf8_unicode_ci NOT NULL,
  `subject_start_date` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subject_end_date` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dataset_size` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subscriber` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `access_instructions` varchar(3000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `licensing_details` varchar(3000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `license_expiration_date` date DEFAULT NULL,
  `erd_url` varchar(1028) COLLATE utf8_unicode_ci DEFAULT NULL,
  `library_catalog_url` varchar(1028) COLLATE utf8_unicode_ci DEFAULT NULL,
  `funder_category` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pubmed_search` varchar(1028) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_added` date DEFAULT NULL,
  `date_updated` date DEFAULT NULL,
  `date_archived` date DEFAULT NULL,
  `archived` tinyint(1) DEFAULT '0',
  `archival_notes` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data_location_description` varchar(3000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_edit_notes` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`dataset_uid`),
  UNIQUE KEY `UNIQ_9D6ABD9EB2FEDB54` (`dataset_uid`),
  UNIQUE KEY `UNIQ_9D6ABD9E2B36786B` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasets`
--

LOCK TABLES `datasets` WRITE;
/*!40000 ALTER TABLE `datasets` DISABLE KEYS */;
INSERT INTO `datasets` VALUES (1,'External','Area Health Resources File',1,'area-health-resources-file','The Area Health Resources Files (AHRF) provides current as well as historic data for more than 6,000 variables for each of the nation\'s counties, as well as state and national data. It contains information on health facilities, health professions, measures of resource scarcity, health status, economic activity, health training programs, and socioeconomic and environmental characteristics. In addition, the basic file contains geographic codes and descriptors which enable it to be linked to many other files and to aggregate counties into various geographic groupings.','2000','Present','100MB',NULL,'Software such as SAS or SPSS or any high level programming language capable of processing large files must be used to extract data. The state and national AHRF ASCII file is a space delimited file and can be used with Excel as well as SAS or SPSS. AHRF Access Systems are also available. These versions of the AHRF have a built-in, user friendly front-end that enables users to extract the desired data into Access or Excel formats. You can also access the data in the MS Access tables directly. SAS file definition is included with the documentation. This definition can be modified for use with SPSS. When using SAS with the 2001 and earlier versions, be sure to include recfm=f in your infile statement. For the 2002 (and later) versions, do not include recfm=f in your infile statement. When using SPSS with the 2001 and previous versions, you should include mode=image and recfm=f in your infile statement. For the 2002 and later versions, you should include mode=character in your infile statement.',NULL,NULL,NULL,NULL,NULL,'https://www.ncbi.nlm.nih.gov/pubmed?otools=nynyumlib&term=\"area%20resource%20files\"[All%20Fields]%20OR%20\"area%20resource%20file\"[All%20Fields]%20OR%20\"area%20resources%20file\"[All%20Fields]%20OR%20\"area%20health%20resource%20file\"[All%20Fields]&cmd=DetailsSearch','2018-01-26','2018-01-29',NULL,0,NULL,NULL,NULL),(2,'External','Women\'s Health Initiative',1,'women-s-health-initiative','The Women\'s Health Initiative (WHI) is a long-term national health study that focuses on strategies for preventing heart disease, breast cancer, colorectal cancer, and osteoporotic fractures in postmenopausal women.Â The study includes data from 161,808 women aged 50-79. Datasets include information on demographics, diet, medical and physical measurements, medical history, outcomes (both adjudicated and self-reported), psychological habits, social habits, personal habits, genotypes, and specimen results.','1993','Present',NULL,NULL,'Researchers can access WHI data in three locations: an online Virtual Data Enclave hosted by the study, on BioLINCC, and on dbGaP. \r\n\r\nData in the Virtual Data Enclave is available for current WHI PIs, Ancillary Study PIs, Former PIs who were active in the first WHI Extension for one year and lead authors on approved papers. To gain access to the Virtual Data Enclave, researchers must prepare a manuscript or ancillary study proposal, complete the WHI Virtual Data Enclave (VDE) Intake Form, sign the WHI Data Distribution Agreement, Sign the WHI Data Access and Use Agreement for the WHI Virtual Data Enclave, provide IRB approval documentation, and provide a Purchase Order. Detailed information on obtaining access can be found on the WHI Researcher Data page.',NULL,NULL,NULL,NULL,NULL,'https://www.ncbi.nlm.nih.gov/pubmed?otools=nynyumlib&term=\"women%27s%20health%20initiative\"%5BTIAB%5D%20OR%20\"womens%20health%20initiative\"%5Btiab%5D&cmd=DetailsSearch','2018-01-29','2018-01-31',NULL,0,NULL,NULL,NULL),(3,'External','Antihypertensive and Lipid-Lowering Treatment to Prevent Heart Attack Trial',1,'antihypertensive-and-lipid-lowering-treatment-to-prevent-heart-attack-trial','ALLHAT was a large antihypertensive trial and lipid-lowering trial and included large numbers of patients over age 65, women, African-Americans, and patients with diabetes, treated largely in community practice settings. Participants were men and women aged 55 years and over with a history of hypertension. Data collected includes participant physical measures, demographics, health behaviors, medical events, hospitalizations, use of antihypertensive medications, use of lipid-lowering medications, use of pravastatin, study retention, medication adherence and administrative details.',NULL,NULL,NULL,NULL,'There are three ways to obtain ALLHAT Data:\r\n\r\n1.  Collaborate with an ALLHAT sponsor and the Coordinating Center at the University of Texas to analyze data and write a paper or a project proposal\r\n\r\n2.  Request a data set to produce your own data runs for your paper or project. Work on your request will proceed after the Coordinating Center receives an IRB approval from your own institution and a Data Distribution Agreement asserting compliance with confidentiality guidelines for use of the data. If approved a Coordinating Center liaison will be assigned\r\n\r\n3.  Request a limited access data set from BioLINCC\r\n\r\nFor options 1 and 2, send a Concept Proposal to Dr. Ellen Breckenridge, at the Coordinating Center to get this process started. Upon request, the Coordinating Center can help identify an ALLHAT sponsor.',NULL,NULL,NULL,NULL,NULL,'http://www.ncbi.nlm.nih.gov/pubmed?myncbishare=nyumedlib&otool=nynyumlib&term=ALLHAT+OR+%22Antihypertensive+and+Lipid-Lowering+Treatment+to+Prevent+Heart+Attack+Trial%22+OR+%22Antihypertensive+and+Lipid-Lowering+Treatment+to+Prevent+Heart+Attack%22','2018-01-29','2018-01-29',NULL,0,NULL,NULL,NULL),(4,'External','United States Renal Data System',1,'united-states-renal-data-system','The United States Renal Data System (USRDS) is a national data system that collects, analyzes, and distributes information about end-stage renal disease (ESRD) in the United States. The USRDS is funded directly by the National Institute of Diabetes and Digestive and Kidney Diseases (NIDDK). USRDS staff collaborates with members of Centers for Medicare & Medicaid Services (CMS), the United Network for Organ Sharing (UNOS), and the ESRD networks, sharing datasets and actively working to improve the accuracy of ESRD patient information.','1994','Present',NULL,NULL,'Annual Data Report available for download as PDF or HTML with reference tables in Excel. Interface to query dataset available with registration. Queries return tables or interactive maps, both of which can be downloaded. Further data available in SAS format for PC with approved application',NULL,NULL,NULL,NULL,NULL,'http://www.ncbi.nlm.nih.gov/pubmed?otools=nynyumlib&term=%22US%20Renal%20data%20system%22%5BAll%20Fields%5D%20OR%20USRDS%5BAll%20Fields%5D%20OR%20%22united%20states%20renal%20data%20system%22%5BAll%20Fields%5D&cmd=DetailsSearch','2018-01-29','2018-01-29',NULL,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `datasets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasets_access_restrictions`
--

DROP TABLE IF EXISTS `datasets_access_restrictions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasets_access_restrictions` (
  `dataset_uid` int(11) NOT NULL,
  `restriction_id` int(11) NOT NULL,
  PRIMARY KEY (`dataset_uid`,`restriction_id`),
  KEY `IDX_878651D2B2FEDB54` (`dataset_uid`),
  KEY `IDX_878651D2E6160631` (`restriction_id`),
  CONSTRAINT `FK_878651D2B2FEDB54` FOREIGN KEY (`dataset_uid`) REFERENCES `datasets` (`dataset_uid`),
  CONSTRAINT `FK_878651D2E6160631` FOREIGN KEY (`restriction_id`) REFERENCES `access_restrictions` (`restriction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasets_access_restrictions`
--

LOCK TABLES `datasets_access_restrictions` WRITE;
/*!40000 ALTER TABLE `datasets_access_restrictions` DISABLE KEYS */;
INSERT INTO `datasets_access_restrictions` VALUES (2,1),(3,1),(4,1),(4,2),(4,3);
/*!40000 ALTER TABLE `datasets_access_restrictions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasets_ages`
--

DROP TABLE IF EXISTS `datasets_ages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasets_ages` (
  `dataset_uid` int(11) NOT NULL,
  `pop_age_id` int(11) NOT NULL,
  PRIMARY KEY (`dataset_uid`,`pop_age_id`),
  KEY `IDX_6364E837B2FEDB54` (`dataset_uid`),
  KEY `IDX_6364E8379296C7E4` (`pop_age_id`),
  CONSTRAINT `FK_6364E8379296C7E4` FOREIGN KEY (`pop_age_id`) REFERENCES `subject_population_ages` (`pop_age_id`),
  CONSTRAINT `FK_6364E837B2FEDB54` FOREIGN KEY (`dataset_uid`) REFERENCES `datasets` (`dataset_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasets_ages`
--

LOCK TABLES `datasets_ages` WRITE;
/*!40000 ALTER TABLE `datasets_ages` DISABLE KEYS */;
INSERT INTO `datasets_ages` VALUES (2,3),(2,4),(2,5);
/*!40000 ALTER TABLE `datasets_ages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasets_awards`
--

DROP TABLE IF EXISTS `datasets_awards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasets_awards` (
  `dataset_uid` int(11) NOT NULL,
  `award_id` int(11) NOT NULL,
  PRIMARY KEY (`dataset_uid`,`award_id`),
  KEY `IDX_59D25F22B2FEDB54` (`dataset_uid`),
  KEY `IDX_59D25F223D5282CF` (`award_id`),
  CONSTRAINT `FK_59D25F223D5282CF` FOREIGN KEY (`award_id`) REFERENCES `awards` (`award_id`),
  CONSTRAINT `FK_59D25F22B2FEDB54` FOREIGN KEY (`dataset_uid`) REFERENCES `datasets` (`dataset_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasets_awards`
--

LOCK TABLES `datasets_awards` WRITE;
/*!40000 ALTER TABLE `datasets_awards` DISABLE KEYS */;
/*!40000 ALTER TABLE `datasets_awards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasets_corresponding_authors`
--

DROP TABLE IF EXISTS `datasets_corresponding_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasets_corresponding_authors` (
  `dataset_uid` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  PRIMARY KEY (`dataset_uid`,`person_id`),
  KEY `IDX_8D3A85B2FEDB54` (`dataset_uid`),
  KEY `IDX_8D3A85217BBB47` (`person_id`),
  CONSTRAINT `FK_8D3A85217BBB47` FOREIGN KEY (`person_id`) REFERENCES `person` (`person_id`),
  CONSTRAINT `FK_8D3A85B2FEDB54` FOREIGN KEY (`dataset_uid`) REFERENCES `datasets` (`dataset_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasets_corresponding_authors`
--

LOCK TABLES `datasets_corresponding_authors` WRITE;
/*!40000 ALTER TABLE `datasets_corresponding_authors` DISABLE KEYS */;
/*!40000 ALTER TABLE `datasets_corresponding_authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasets_data_types`
--

DROP TABLE IF EXISTS `datasets_data_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasets_data_types` (
  `dataset_uid` int(11) NOT NULL,
  `data_type_id` int(11) NOT NULL,
  PRIMARY KEY (`dataset_uid`,`data_type_id`),
  KEY `IDX_F965C516B2FEDB54` (`dataset_uid`),
  KEY `IDX_F965C516A147DA62` (`data_type_id`),
  CONSTRAINT `FK_F965C516A147DA62` FOREIGN KEY (`data_type_id`) REFERENCES `data_types` (`data_type_id`),
  CONSTRAINT `FK_F965C516B2FEDB54` FOREIGN KEY (`dataset_uid`) REFERENCES `datasets` (`dataset_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasets_data_types`
--

LOCK TABLES `datasets_data_types` WRITE;
/*!40000 ALTER TABLE `datasets_data_types` DISABLE KEYS */;
INSERT INTO `datasets_data_types` VALUES (1,1),(2,2),(2,3),(2,4),(2,5),(2,6),(3,1),(3,3),(3,4),(3,6),(3,7);
/*!40000 ALTER TABLE `datasets_data_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasets_dataset_formats`
--

DROP TABLE IF EXISTS `datasets_dataset_formats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasets_dataset_formats` (
  `dataset_uid` int(11) NOT NULL,
  `data_format_id` int(11) NOT NULL,
  PRIMARY KEY (`dataset_uid`,`data_format_id`),
  KEY `IDX_B268C130B2FEDB54` (`dataset_uid`),
  KEY `IDX_B268C1305986B633` (`data_format_id`),
  CONSTRAINT `FK_B268C1305986B633` FOREIGN KEY (`data_format_id`) REFERENCES `dataset_formats` (`data_format_id`),
  CONSTRAINT `FK_B268C130B2FEDB54` FOREIGN KEY (`dataset_uid`) REFERENCES `datasets` (`dataset_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasets_dataset_formats`
--

LOCK TABLES `datasets_dataset_formats` WRITE;
/*!40000 ALTER TABLE `datasets_dataset_formats` DISABLE KEYS */;
INSERT INTO `datasets_dataset_formats` VALUES (1,1),(1,2),(2,1),(2,3),(2,4),(3,3),(3,4);
/*!40000 ALTER TABLE `datasets_dataset_formats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasets_experts`
--

DROP TABLE IF EXISTS `datasets_experts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasets_experts` (
  `dataset_uid` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  PRIMARY KEY (`dataset_uid`,`person_id`),
  KEY `IDX_C8A5267B2FEDB54` (`dataset_uid`),
  KEY `IDX_C8A5267217BBB47` (`person_id`),
  CONSTRAINT `FK_C8A5267217BBB47` FOREIGN KEY (`person_id`) REFERENCES `person` (`person_id`),
  CONSTRAINT `FK_C8A5267B2FEDB54` FOREIGN KEY (`dataset_uid`) REFERENCES `datasets` (`dataset_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasets_experts`
--

LOCK TABLES `datasets_experts` WRITE;
/*!40000 ALTER TABLE `datasets_experts` DISABLE KEYS */;
INSERT INTO `datasets_experts` VALUES (1,1),(2,1),(3,1),(4,1);
/*!40000 ALTER TABLE `datasets_experts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasets_genders`
--

DROP TABLE IF EXISTS `datasets_genders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasets_genders` (
  `dataset_uid` int(11) NOT NULL,
  `gender_id` int(11) NOT NULL,
  PRIMARY KEY (`dataset_uid`,`gender_id`),
  KEY `IDX_C020EFEB2FEDB54` (`dataset_uid`),
  KEY `IDX_C020EFE708A0E0` (`gender_id`),
  CONSTRAINT `FK_C020EFE708A0E0` FOREIGN KEY (`gender_id`) REFERENCES `subject_genders` (`gender_id`),
  CONSTRAINT `FK_C020EFEB2FEDB54` FOREIGN KEY (`dataset_uid`) REFERENCES `datasets` (`dataset_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasets_genders`
--

LOCK TABLES `datasets_genders` WRITE;
/*!40000 ALTER TABLE `datasets_genders` DISABLE KEYS */;
INSERT INTO `datasets_genders` VALUES (2,2);
/*!40000 ALTER TABLE `datasets_genders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasets_geographic_area_details`
--

DROP TABLE IF EXISTS `datasets_geographic_area_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasets_geographic_area_details` (
  `dataset_uid` int(11) NOT NULL,
  `area_detail_id` int(11) NOT NULL,
  PRIMARY KEY (`dataset_uid`,`area_detail_id`),
  KEY `IDX_8DCE8E31B2FEDB54` (`dataset_uid`),
  KEY `IDX_8DCE8E314DAC4667` (`area_detail_id`),
  CONSTRAINT `FK_8DCE8E314DAC4667` FOREIGN KEY (`area_detail_id`) REFERENCES `subject_geographic_area_details` (`area_detail_id`),
  CONSTRAINT `FK_8DCE8E31B2FEDB54` FOREIGN KEY (`dataset_uid`) REFERENCES `datasets` (`dataset_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasets_geographic_area_details`
--

LOCK TABLES `datasets_geographic_area_details` WRITE;
/*!40000 ALTER TABLE `datasets_geographic_area_details` DISABLE KEYS */;
INSERT INTO `datasets_geographic_area_details` VALUES (1,1),(2,1);
/*!40000 ALTER TABLE `datasets_geographic_area_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasets_geographic_areas`
--

DROP TABLE IF EXISTS `datasets_geographic_areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasets_geographic_areas` (
  `dataset_uid` int(11) NOT NULL,
  `area_id` int(11) NOT NULL,
  PRIMARY KEY (`dataset_uid`,`area_id`),
  KEY `IDX_38876EF3B2FEDB54` (`dataset_uid`),
  KEY `IDX_38876EF3BD0F409C` (`area_id`),
  CONSTRAINT `FK_38876EF3B2FEDB54` FOREIGN KEY (`dataset_uid`) REFERENCES `datasets` (`dataset_uid`),
  CONSTRAINT `FK_38876EF3BD0F409C` FOREIGN KEY (`area_id`) REFERENCES `subject_geographic_areas` (`area_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasets_geographic_areas`
--

LOCK TABLES `datasets_geographic_areas` WRITE;
/*!40000 ALTER TABLE `datasets_geographic_areas` DISABLE KEYS */;
INSERT INTO `datasets_geographic_areas` VALUES (2,2),(4,1);
/*!40000 ALTER TABLE `datasets_geographic_areas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasets_keywords`
--

DROP TABLE IF EXISTS `datasets_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasets_keywords` (
  `dataset_uid` int(11) NOT NULL,
  `keyword_id` int(11) NOT NULL,
  PRIMARY KEY (`dataset_uid`,`keyword_id`),
  KEY `IDX_4505BCD2B2FEDB54` (`dataset_uid`),
  KEY `IDX_4505BCD2115D4552` (`keyword_id`),
  CONSTRAINT `FK_4505BCD2115D4552` FOREIGN KEY (`keyword_id`) REFERENCES `subject_keywords` (`keyword_id`),
  CONSTRAINT `FK_4505BCD2B2FEDB54` FOREIGN KEY (`dataset_uid`) REFERENCES `datasets` (`dataset_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasets_keywords`
--

LOCK TABLES `datasets_keywords` WRITE;
/*!40000 ALTER TABLE `datasets_keywords` DISABLE KEYS */;
INSERT INTO `datasets_keywords` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(2,9),(2,10),(2,11),(2,12),(2,13),(2,14),(2,15),(3,13),(3,16),(3,17),(3,18),(3,19),(3,20),(3,21),(3,22),(3,23),(3,24),(3,25),(3,26),(4,27);
/*!40000 ALTER TABLE `datasets_keywords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasets_publications`
--

DROP TABLE IF EXISTS `datasets_publications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasets_publications` (
  `dataset_uid` int(11) NOT NULL,
  `publication_id` int(11) NOT NULL,
  PRIMARY KEY (`dataset_uid`,`publication_id`),
  KEY `IDX_EAC742CFB2FEDB54` (`dataset_uid`),
  KEY `IDX_EAC742CF38B217A7` (`publication_id`),
  CONSTRAINT `FK_EAC742CF38B217A7` FOREIGN KEY (`publication_id`) REFERENCES `publications` (`publication_id`),
  CONSTRAINT `FK_EAC742CFB2FEDB54` FOREIGN KEY (`dataset_uid`) REFERENCES `datasets` (`dataset_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasets_publications`
--

LOCK TABLES `datasets_publications` WRITE;
/*!40000 ALTER TABLE `datasets_publications` DISABLE KEYS */;
/*!40000 ALTER TABLE `datasets_publications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasets_publishers`
--

DROP TABLE IF EXISTS `datasets_publishers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasets_publishers` (
  `dataset_uid` int(11) NOT NULL,
  `publisher_id` int(11) NOT NULL,
  PRIMARY KEY (`dataset_uid`,`publisher_id`),
  KEY `IDX_6AC743C2B2FEDB54` (`dataset_uid`),
  KEY `IDX_6AC743C240C86FCE` (`publisher_id`),
  CONSTRAINT `FK_6AC743C240C86FCE` FOREIGN KEY (`publisher_id`) REFERENCES `publishers` (`publisher_id`),
  CONSTRAINT `FK_6AC743C2B2FEDB54` FOREIGN KEY (`dataset_uid`) REFERENCES `datasets` (`dataset_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasets_publishers`
--

LOCK TABLES `datasets_publishers` WRITE;
/*!40000 ALTER TABLE `datasets_publishers` DISABLE KEYS */;
INSERT INTO `datasets_publishers` VALUES (1,1),(2,2),(4,3);
/*!40000 ALTER TABLE `datasets_publishers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasets_related_equipment`
--

DROP TABLE IF EXISTS `datasets_related_equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasets_related_equipment` (
  `dataset_uid` int(11) NOT NULL,
  `related_equipment_id` int(11) NOT NULL,
  PRIMARY KEY (`dataset_uid`,`related_equipment_id`),
  KEY `IDX_84607E46B2FEDB54` (`dataset_uid`),
  KEY `IDX_84607E46BB6145B9` (`related_equipment_id`),
  CONSTRAINT `FK_84607E46B2FEDB54` FOREIGN KEY (`dataset_uid`) REFERENCES `datasets` (`dataset_uid`),
  CONSTRAINT `FK_84607E46BB6145B9` FOREIGN KEY (`related_equipment_id`) REFERENCES `related_equipment` (`related_equipment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasets_related_equipment`
--

LOCK TABLES `datasets_related_equipment` WRITE;
/*!40000 ALTER TABLE `datasets_related_equipment` DISABLE KEYS */;
/*!40000 ALTER TABLE `datasets_related_equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasets_related_software`
--

DROP TABLE IF EXISTS `datasets_related_software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasets_related_software` (
  `dataset_uid` int(11) NOT NULL,
  `related_software_id` int(11) NOT NULL,
  PRIMARY KEY (`dataset_uid`,`related_software_id`),
  KEY `IDX_47CE88BBB2FEDB54` (`dataset_uid`),
  KEY `IDX_47CE88BB1CAE59C5` (`related_software_id`),
  CONSTRAINT `FK_47CE88BB1CAE59C5` FOREIGN KEY (`related_software_id`) REFERENCES `related_software` (`related_software_id`),
  CONSTRAINT `FK_47CE88BBB2FEDB54` FOREIGN KEY (`dataset_uid`) REFERENCES `datasets` (`dataset_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasets_related_software`
--

LOCK TABLES `datasets_related_software` WRITE;
/*!40000 ALTER TABLE `datasets_related_software` DISABLE KEYS */;
/*!40000 ALTER TABLE `datasets_related_software` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasets_standards`
--

DROP TABLE IF EXISTS `datasets_standards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasets_standards` (
  `dataset_uid` int(11) NOT NULL,
  `standard_id` int(11) NOT NULL,
  PRIMARY KEY (`dataset_uid`,`standard_id`),
  KEY `IDX_8C23BB5DB2FEDB54` (`dataset_uid`),
  KEY `IDX_8C23BB5D6F9BFC42` (`standard_id`),
  CONSTRAINT `FK_8C23BB5D6F9BFC42` FOREIGN KEY (`standard_id`) REFERENCES `measurement_standards` (`standard_id`),
  CONSTRAINT `FK_8C23BB5DB2FEDB54` FOREIGN KEY (`dataset_uid`) REFERENCES `datasets` (`dataset_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasets_standards`
--

LOCK TABLES `datasets_standards` WRITE;
/*!40000 ALTER TABLE `datasets_standards` DISABLE KEYS */;
/*!40000 ALTER TABLE `datasets_standards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasets_study_types`
--

DROP TABLE IF EXISTS `datasets_study_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasets_study_types` (
  `dataset_uid` int(11) NOT NULL,
  `study_type_id` int(11) NOT NULL,
  PRIMARY KEY (`dataset_uid`,`study_type_id`),
  KEY `IDX_B4193878B2FEDB54` (`dataset_uid`),
  KEY `IDX_B4193878F05971F1` (`study_type_id`),
  CONSTRAINT `FK_B4193878B2FEDB54` FOREIGN KEY (`dataset_uid`) REFERENCES `datasets` (`dataset_uid`),
  CONSTRAINT `FK_B4193878F05971F1` FOREIGN KEY (`study_type_id`) REFERENCES `study_types` (`study_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasets_study_types`
--

LOCK TABLES `datasets_study_types` WRITE;
/*!40000 ALTER TABLE `datasets_study_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `datasets_study_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasets_subject_domains`
--

DROP TABLE IF EXISTS `datasets_subject_domains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasets_subject_domains` (
  `dataset_uid` int(11) NOT NULL,
  `subject_domain_id` int(11) NOT NULL,
  PRIMARY KEY (`dataset_uid`,`subject_domain_id`),
  KEY `IDX_BDFF4475B2FEDB54` (`dataset_uid`),
  KEY `IDX_BDFF4475520E9ACF` (`subject_domain_id`),
  CONSTRAINT `FK_BDFF4475520E9ACF` FOREIGN KEY (`subject_domain_id`) REFERENCES `subject_domains` (`subject_domain_id`),
  CONSTRAINT `FK_BDFF4475B2FEDB54` FOREIGN KEY (`dataset_uid`) REFERENCES `datasets` (`dataset_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasets_subject_domains`
--

LOCK TABLES `datasets_subject_domains` WRITE;
/*!40000 ALTER TABLE `datasets_subject_domains` DISABLE KEYS */;
INSERT INTO `datasets_subject_domains` VALUES (1,1),(1,2),(1,3),(1,4),(2,5),(2,6),(2,7),(3,6),(3,7),(3,8),(4,6);
/*!40000 ALTER TABLE `datasets_subject_domains` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datasets_subject_of_study`
--

DROP TABLE IF EXISTS `datasets_subject_of_study`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datasets_subject_of_study` (
  `dataset_uid` int(11) NOT NULL,
  `subject_of_study_id` int(11) NOT NULL,
  PRIMARY KEY (`dataset_uid`,`subject_of_study_id`),
  KEY `IDX_F7EA2066B2FEDB54` (`dataset_uid`),
  KEY `IDX_F7EA2066C3222D26` (`subject_of_study_id`),
  CONSTRAINT `FK_F7EA2066B2FEDB54` FOREIGN KEY (`dataset_uid`) REFERENCES `datasets` (`dataset_uid`),
  CONSTRAINT `FK_F7EA2066C3222D26` FOREIGN KEY (`subject_of_study_id`) REFERENCES `subject_of_study` (`subject_of_study_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datasets_subject_of_study`
--

LOCK TABLES `datasets_subject_of_study` WRITE;
/*!40000 ALTER TABLE `datasets_subject_of_study` DISABLE KEYS */;
/*!40000 ALTER TABLE `datasets_subject_of_study` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `measurement_standards`
--

DROP TABLE IF EXISTS `measurement_standards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `measurement_standards` (
  `standard_id` int(11) NOT NULL AUTO_INCREMENT,
  `measurement_standard_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `measurement_standard_authority` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`standard_id`),
  UNIQUE KEY `UNIQ_C920F03C2217D67C` (`measurement_standard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `measurement_standards`
--

LOCK TABLES `measurement_standards` WRITE;
/*!40000 ALTER TABLE `measurement_standards` DISABLE KEYS */;
/*!40000 ALTER TABLE `measurement_standards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `other_resources`
--

DROP TABLE IF EXISTS `other_resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `other_resources` (
  `other_resource_id` int(11) NOT NULL AUTO_INCREMENT,
  `datasets_dataset_uid` int(11) DEFAULT NULL,
  `resource_name` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `resource_description` varchar(1028) COLLATE utf8_unicode_ci DEFAULT NULL,
  `resource_url` varchar(1028) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`other_resource_id`),
  KEY `IDX_3199621BAD3AFC` (`datasets_dataset_uid`),
  CONSTRAINT `FK_3199621BAD3AFC` FOREIGN KEY (`datasets_dataset_uid`) REFERENCES `datasets` (`dataset_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `other_resources`
--

LOCK TABLES `other_resources` WRITE;
/*!40000 ALTER TABLE `other_resources` DISABLE KEYS */;
/*!40000 ALTER TABLE `other_resources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person`
--

DROP TABLE IF EXISTS `person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `person` (
  `person_id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `kid` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `orcid_id` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bio_url` varchar(1028) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`person_id`),
  UNIQUE KEY `UNIQ_34DCD176989D9B62` (`slug`),
  UNIQUE KEY `UNIQ_34DCD1764523887C` (`kid`),
  UNIQUE KEY `UNIQ_34DCD1762018B8C2` (`orcid_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person`
--

LOCK TABLES `person` WRITE;
/*!40000 ALTER TABLE `person` DISABLE KEYS */;
INSERT INTO `person` VALUES (1,'David Martin','david-martin',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person_associations`
--

DROP TABLE IF EXISTS `person_associations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `person_associations` (
  `person_association_id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL,
  `datasets_dataset_uid` int(11) NOT NULL,
  `role` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `is_corresponding_author` tinyint(1) NOT NULL,
  `display_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`person_association_id`),
  KEY `IDX_6A2F24FC217BBB47` (`person_id`),
  KEY `IDX_6A2F24FCAD3AFC` (`datasets_dataset_uid`),
  CONSTRAINT `FK_6A2F24FC217BBB47` FOREIGN KEY (`person_id`) REFERENCES `person` (`person_id`),
  CONSTRAINT `FK_6A2F24FCAD3AFC` FOREIGN KEY (`datasets_dataset_uid`) REFERENCES `datasets` (`dataset_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person_associations`
--

LOCK TABLES `person_associations` WRITE;
/*!40000 ALTER TABLE `person_associations` DISABLE KEYS */;
/*!40000 ALTER TABLE `person_associations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publications`
--

DROP TABLE IF EXISTS `publications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `publications` (
  `publication_id` int(11) NOT NULL AUTO_INCREMENT,
  `citation` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(1028) COLLATE utf8_unicode_ci DEFAULT NULL,
  `doi` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`publication_id`),
  UNIQUE KEY `UNIQ_32783AF4989D9B62` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publications`
--

LOCK TABLES `publications` WRITE;
/*!40000 ALTER TABLE `publications` DISABLE KEYS */;
/*!40000 ALTER TABLE `publications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publisher_categories`
--

DROP TABLE IF EXISTS `publisher_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `publisher_categories` (
  `publisher_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `publisher_category` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`publisher_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publisher_categories`
--

LOCK TABLES `publisher_categories` WRITE;
/*!40000 ALTER TABLE `publisher_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `publisher_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publishers`
--

DROP TABLE IF EXISTS `publishers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `publishers` (
  `publisher_id` int(11) NOT NULL AUTO_INCREMENT,
  `publisher_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `publisher_url` varchar(1028) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`publisher_id`),
  UNIQUE KEY `UNIQ_842DC37BBF3AAE51` (`publisher_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publishers`
--

LOCK TABLES `publishers` WRITE;
/*!40000 ALTER TABLE `publishers` DISABLE KEYS */;
INSERT INTO `publishers` VALUES (1,'United States - Health Resources and Services Administration (HRSA)','united-states-health-resources-and-services-administration-hrsa','http://www.hrsa.gov'),(2,'Fred Hutchinson Cancer Research Center','fred-hutchinson-cancer-research-center','https://www.fredhutch.org/en.html'),(3,'United States - Renal Data System (USRDS)','united-states-renal-data-system-usrds','https://www.usrds.org');
/*!40000 ALTER TABLE `publishers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `related_equipment`
--

DROP TABLE IF EXISTS `related_equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `related_equipment` (
  `related_equipment_id` int(11) NOT NULL AUTO_INCREMENT,
  `related_equipment` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `equipment_description` varchar(1028) COLLATE utf8_unicode_ci DEFAULT NULL,
  `equipment_url` varchar(1028) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`related_equipment_id`),
  UNIQUE KEY `UNIQ_7BF989987BF98998` (`related_equipment`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `related_equipment`
--

LOCK TABLES `related_equipment` WRITE;
/*!40000 ALTER TABLE `related_equipment` DISABLE KEYS */;
/*!40000 ALTER TABLE `related_equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `related_software`
--

DROP TABLE IF EXISTS `related_software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `related_software` (
  `related_software_id` int(11) NOT NULL AUTO_INCREMENT,
  `software_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `software_description` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `software_url` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`related_software_id`),
  UNIQUE KEY `UNIQ_D15326627B2674FA` (`software_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `related_software`
--

LOCK TABLES `related_software` WRITE;
/*!40000 ALTER TABLE `related_software` DISABLE KEYS */;
/*!40000 ALTER TABLE `related_software` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `study_types`
--

DROP TABLE IF EXISTS `study_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `study_types` (
  `study_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `study_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`study_type_id`),
  UNIQUE KEY `UNIQ_64AD9D0F306BF10` (`study_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `study_types`
--

LOCK TABLES `study_types` WRITE;
/*!40000 ALTER TABLE `study_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `study_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject_domains`
--

DROP TABLE IF EXISTS `subject_domains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject_domains` (
  `subject_domain_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_domain` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mesh_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`subject_domain_id`),
  UNIQUE KEY `UNIQ_29F9133F2FB0D72C` (`subject_domain`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_domains`
--

LOCK TABLES `subject_domains` WRITE;
/*!40000 ALTER TABLE `subject_domains` DISABLE KEYS */;
INSERT INTO `subject_domains` VALUES (1,'Delivery of Health Care','https://id.nlm.nih.gov/mesh/D003695.html','delivery-of-health-care'),(2,'Health Care Costs','https://id.nlm.nih.gov/mesh/D017048','health-care-costs'),(3,'Population Characteristics','https://id.nlm.nih.gov/mesh/D011154','population-characteristics'),(4,'Quality of Health Care','https://id.nlm.nih.gov/mesh/D011787','quality-of-health-care'),(5,'Cancer','https://id.nlm.nih.gov/mesh/D009369','cancer'),(6,'Chronic Disease','https://id.nlm.nih.gov/mesh/D002908','chronic-disease'),(7,'Health Status','https://id.nlm.nih.gov/mesh/D006304','health-status'),(8,'Health Care Utilization','https://id.nlm.nih.gov/mesh/D010342','health-care-utilization');
/*!40000 ALTER TABLE `subject_domains` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject_genders`
--

DROP TABLE IF EXISTS `subject_genders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject_genders` (
  `gender_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_gender` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`gender_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_genders`
--

LOCK TABLES `subject_genders` WRITE;
/*!40000 ALTER TABLE `subject_genders` DISABLE KEYS */;
INSERT INTO `subject_genders` VALUES (1,'Male','male'),(2,'Female','female'),(3,'Transgender','transgender');
/*!40000 ALTER TABLE `subject_genders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject_geographic_area_details`
--

DROP TABLE IF EXISTS `subject_geographic_area_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject_geographic_area_details` (
  `area_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `geographic_area_detail_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `geographic_area_detail_authority` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`area_detail_id`),
  UNIQUE KEY `UNIQ_2CDC7752EE8E453` (`geographic_area_detail_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_geographic_area_details`
--

LOCK TABLES `subject_geographic_area_details` WRITE;
/*!40000 ALTER TABLE `subject_geographic_area_details` DISABLE KEYS */;
INSERT INTO `subject_geographic_area_details` VALUES (1,'United States',NULL,'united-states'),(2,'Women\'s Health Initiative',NULL,'women-s-health-initiative');
/*!40000 ALTER TABLE `subject_geographic_area_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject_geographic_areas`
--

DROP TABLE IF EXISTS `subject_geographic_areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject_geographic_areas` (
  `area_id` int(11) NOT NULL AUTO_INCREMENT,
  `geographic_area_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `geographic_area_authority` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`area_id`),
  UNIQUE KEY `UNIQ_CFF2E3058571112D` (`geographic_area_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_geographic_areas`
--

LOCK TABLES `subject_geographic_areas` WRITE;
/*!40000 ALTER TABLE `subject_geographic_areas` DISABLE KEYS */;
INSERT INTO `subject_geographic_areas` VALUES (1,'United States',NULL,'united-states'),(2,'National',NULL,'national');
/*!40000 ALTER TABLE `subject_geographic_areas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject_keywords`
--

DROP TABLE IF EXISTS `subject_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject_keywords` (
  `keyword_id` int(11) NOT NULL AUTO_INCREMENT,
  `keyword` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`keyword_id`),
  UNIQUE KEY `UNIQ_9222F5365A93713B` (`keyword`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_keywords`
--

LOCK TABLES `subject_keywords` WRITE;
/*!40000 ALTER TABLE `subject_keywords` DISABLE KEYS */;
INSERT INTO `subject_keywords` VALUES (1,'Economic activity','economic-activity'),(2,'Environmental characteristics','environmental-characteristics'),(3,'Health care providers and facilities','health-care-providers-and-facilities'),(4,'Health expenditures','health-expenditures'),(5,'Health status','health-status'),(6,'Health training programs','health-training-programs'),(7,'Measures of resource scarcity','measures-of-resource-scarcity'),(8,'Socioeconomics','socioeconomics'),(9,'Breast cancer','breast-cancer'),(10,'Colorectal cancer','colorectal-cancer'),(11,'Diet','diet'),(12,'Dietary supplements','dietary-supplements'),(13,'Heart diseases','heart-diseases'),(14,'Osteoporotic fractures','osteoporotic-fractures'),(15,'Postmenopause','postmenopause'),(16,'African Americans','african-americans'),(17,'Blood pressure','blood-pressure'),(18,'Cardiovascular disease','cardiovascular-disease'),(19,'Cholesterol','cholesterol'),(20,'Clinical trial','clinical-trial'),(21,'Hypertension','hypertension'),(22,'Hypolipidemic agents','hypolipidemic-agents'),(23,'Lipid-lowering','lipid-lowering'),(24,'Myocardial infarction','myocardial-infarction'),(25,'Pravastatin','pravastatin'),(26,'Statin','statin'),(27,'Chronic kidney failure','chronic-kidney-failure');
/*!40000 ALTER TABLE `subject_keywords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject_of_study`
--

DROP TABLE IF EXISTS `subject_of_study`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject_of_study` (
  `subject_of_study_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_of_study` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `species` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`subject_of_study_id`),
  UNIQUE KEY `UNIQ_61778EBF61778EBF` (`subject_of_study`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_of_study`
--

LOCK TABLES `subject_of_study` WRITE;
/*!40000 ALTER TABLE `subject_of_study` DISABLE KEYS */;
/*!40000 ALTER TABLE `subject_of_study` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject_population_ages`
--

DROP TABLE IF EXISTS `subject_population_ages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject_population_ages` (
  `pop_age_id` int(11) NOT NULL AUTO_INCREMENT,
  `age_group` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`pop_age_id`),
  UNIQUE KEY `UNIQ_62C02E49F88B4253` (`age_group`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_population_ages`
--

LOCK TABLES `subject_population_ages` WRITE;
/*!40000 ALTER TABLE `subject_population_ages` DISABLE KEYS */;
INSERT INTO `subject_population_ages` VALUES (1,'3','3'),(2,'123','123'),(3,'Adult (19 years - 64 years)','adult-19-years-64-years'),(4,'Senior (65 years - 79 years)','senior-65-years-79-years'),(5,'Aged (80 years and over)','aged-80-years-and-over');
/*!40000 ALTER TABLE `subject_population_ages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_role` (
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `IDX_2DE8C6A3A76ED395` (`user_id`),
  KEY `IDX_2DE8C6A3D60322AC` (`role_id`),
  CONSTRAINT `FK_2DE8C6A3A76ED395` FOREIGN KEY (`user_id`) REFERENCES `datacatalog_users` (`user_id`),
  CONSTRAINT `FK_2DE8C6A3D60322AC` FOREIGN KEY (`role_id`) REFERENCES `datacatalog_user_roles` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_role`
--

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-02-01 15:13:52
